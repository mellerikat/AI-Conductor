source env.sh

ecr_aic_webserver=${aic_ecr_url}/${aic_ecr_prefix}/aic-webserver
dockerfile=${TOP}/work/Dockerfile
git_tag=$(git rev-parse --short HEAD)

echo "########################################################################"
echo "AWS_PROFILE : ${AWS_PROFILE}"
echo "repository  : ${ecr_aic_webserver}"
echo "image tag   : ${git_tag}"
echo "########################################################################"
echo ""

# build a docker image and tag
docker build -t ${ecr_aic_webserver}:${git_tag} -f ${dockerfile} ${TOP}/work
docker tag ${ecr_aic_webserver}:${git_tag} ${ecr_aic_webserver}:latest

# login ECR
aws ecr get-login-password --region ap-northeast-2 --profile ${AWS_PROFILE} | docker login --username AWS --password-stdin ${aic_ecr_url}

# push to ECR
docker push ${ecr_aic_webserver}:${git_tag}
docker push ${ecr_aic_webserver}:latest

# logout ECR
docker logout

