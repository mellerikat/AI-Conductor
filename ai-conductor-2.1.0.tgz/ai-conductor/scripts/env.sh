TOP=$(realpath ../../..)

# aws
AWS_PROFILE=meerkat-dev-mfa
aic_aws_region=ap-northeast-2

# env for ECR
aic_ecr_url=339713051385.dkr.ecr.ap-northeast-2.amazonaws.com

aic_ecr_prefix=ecr-repo-an2-meerkat-dev/ai-advisor/ai-conductor


# env for production
AIC_IS_PRODUCT_ENV=1


